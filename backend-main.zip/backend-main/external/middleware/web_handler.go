package middleware
import (
	log "github.com/sirupsen/logrus"
)
type WebHandler struct {
	logger         *log.Logger
}