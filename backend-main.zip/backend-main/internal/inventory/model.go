package inventory

type Inventory struct {

}
