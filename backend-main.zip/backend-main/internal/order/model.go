package order

type Order struct {
	UserID uint

}
